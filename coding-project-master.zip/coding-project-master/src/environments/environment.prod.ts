export const environment = {
    production: true,
    appId: '97bb329624343efc95ee5e49728d951e',
    baseUrl: 'http://api.openweathermap.org/data/2.5/forecast',
    units: 'metric',
    days: '16'
};
