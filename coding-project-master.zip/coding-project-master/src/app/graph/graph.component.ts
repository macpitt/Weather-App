import { WeatherService } from './../form/services/weatherService';
import { Component, OnChanges, Input, OnInit, ViewEncapsulation } from '@angular/core';
// import { WeatherService } from '../form/services/weatherService';
import { ChartConfiguration } from './graph.component.interface';
import * as c3 from 'c3';
import * as d3 from 'd3';
@Component({
    selector: 'app-graph',
    templateUrl: './graph.component.html',
    styleUrls: ['./graph.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class GraphComponent implements OnChanges, OnInit {
    weatherData;
    errorMessage;
    formattedDatesList;
    tempList;
    windList;
    cityName;
    countryName;
    fore;
    @Input() chartConfig: ChartConfiguration;

    constructor(private weatherService: WeatherService) { }
    ngOnInit() {
        // this.tempList = this.weatherService.tempList;
        // this.formattedDatesList = this.weatherService.datesList;
        // this.getFormattedDates();
        // this.getTempList();
    }

    ngOnChanges() {
        this.getFormattedDates();
        this.getTempList();
        this.getWindList();
        this.getCityName();
        this.getCountryName();
        this.fore = this.weatherService.modifiedData.forecastDesc;
        const data = {
            selection: {
                enabled: true
            },
            x: 'data',
            y: 'temp',
            columns: [
                ['data'].concat(this.formattedDatesList),
                ['temp'].concat(this.tempList)
                // ['data'].concat(this.windList),
            ],
            type: 'area-spline',
            // labels: true
            labels: {
                format: function (d) { return d + '°C'; }
            },
            // onrendered: function (d) {
            //     //     const self = this;
            //     //     d3.select(this.config.bindto)
            //     //         .selectAll('.c3-axis-x .tick text')
            //     //         .on('click', function (d) {
            //     //             console.log('data val', d, 'gives us');
            //     //             alert(d);
            //     //         });
            //     d3.select(this.config.bindto)
            //         .selectAll('.c3-chart-text .c3-texts .c3-text')
            //         .filter(function () {
            //             return d < 0;s
            //         })
            //         .select('text')
            //         .attr('class', 'ative');
            // },
            // onclick: function (d, i) {
            //     d3.select(this.config.bindto)
            //         .selectAll('.c3-axis-x .tick')
            //         .on('click', function () {
            //             console.log('data val', d, 'gives us');
            //             alert(d);
            //         });
            // },
            onclick: function (d, element) {
                console.log('selected x: ' + chart.categories()[d.index] + ' value: ' + chart.selected()[0].value + ' name: ' + chart.selected()[0].name);
            },
        };

        const config = {
            // 'onselected': function (d, element) {
            //     alert('selected x: ' + chart.categories()[d.index] + ' value: ' + chart.selected()[0].value + ' name: ' + chart.selected()[0].name);
            // },
            // 'bindto': '#chart',
            'data': data,
            // 'size': { 'height': 700 },
            // 'zoom': { 'enabled': false, 'rescale': true },
            // 'grid': { 'x': { 'show': false } },
            'legend': {
                'hide': true
            },
            'axis': {
                'y': {
                    // 'type': 'category',
                    // 'label': 'Temp in °C',
                    // 'min': -1,
                    'show': false,
                    'tick': {
                        'format': function (d) {
                            // if (d < 0) {
                            //     d3.selectAll('.c3-chart-text .c3-texts .c3-text')
                            //         .filter(function () {
                            //             return d < 0;
                            //         })
                            //         .select('text')
                            //         .attr('class', 'ative');
                            // }
                            d3.selectAll('.tick')
                                .on('click', function (value, index) {
                                    alert('You clicked a tick.');
                                });
                            return d + '°C';
                        },
                        'position': 'outer-middle',
                    }
                },
                // 'y2': { 'show': true, 'label': 'Revenue', 'tick': {} },
                'x': {
                    'padding': {
                        'left': 0,
                        'right': 0,
                    },
                    type: 'category',
                    'tick': {
                        // 'culling': { 'max': 100 },
                        // 'culling': true,
                        // 'culling': {
                        //     'max': window.innerWidth > 800 ? 8 : 4,
                        // },
                        // 'count': 20,
                        'fit': true,
                        // 'rotate': 45,
                        'width': 35,
                        'line-height': 1.1,
                        // 'format': '%a %d'
                        'outer': false
                    }
                }
            },
            'area': {
                'zerobased': false
            },
            'color': {
                'pattern': ['#00BBE4']
            }
        };
        const chart = c3.generate(config);
        // this.getchartdata(this.cityName);
        // const chart = c3.generate({
        //     bindto: '#chart',
        //     // xFormat: '%Y-%m-%d', // how the date is parsed
        //     data: {
        //         x: 'data',
        //         // xFormat: '%s',
        //         //        xFormat: '%Y%m%d', // 'xFormat' can be used as custom format of 'x'
        //         columns: [
        //             ['data'].concat(this.formattedDatesList),
        //             ['temp'].concat(this.tempList),
        //             // ['data2', 130, 340, 200, 500, 250, 350]
        //         ],
        //         type: 'spline'
        //     },
        //     axis: {
        //         x: {
        //             type: 'timeseries',
        //             tick: {
        //                 format: '%d %m'
        //             }
        //         }
        //     }
        // });

        // setTimeout(function () {
        //     chart.load({
        //         columns: [
        //             ['data3', 400, 500, 450, 700, 600, 500]
        //         ]
        //     });
        // }, 1000);
    }

    getFormattedDates() {
        return this.formattedDatesList = this.weatherService.getDatesList();
    }

    getTempList() {
        return this.tempList = this.weatherService.getTempList();
    }

    getWindList() {
        return this.windList = this.weatherService.getWindList();
    }

    getCityName() {
        return this.cityName = this.weatherService.cityName;
    }

    getCountryName() {
        return this.countryName = this.weatherService.countryName;
    }

}
