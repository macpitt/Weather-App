/** Interface for donut chart configuration */
export interface ChartConfiguration {
    chartData: Array<any>;
    // width: number;
    // height: number;
    dt: string;
    temp: number;
    main: object;
    xFormat;
}
