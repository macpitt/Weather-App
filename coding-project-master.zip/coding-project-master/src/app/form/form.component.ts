import { Component, OnInit } from '@angular/core';
import { WeatherService } from '../form/services/weatherService';
import { ChartConfiguration } from '../graph/graph.component.interface';
import 'rxjs/add/operator/finally';

@Component({
    selector: 'app-form',
    templateUrl: './form.component.html',
    styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {
    weatherData;
    errorMessage;
    cityName: string;
    disabledButton = true;
    chartConfiguration: ChartConfiguration;
    constructor(private weatherService: WeatherService) { }

    ngOnInit() {

    }
    onSubmitDatabinding() {
        console.log('inside the two way:' + this.cityName);
        this.weatherService.getWeatherForecast(this.cityName)
            .finally(() => {
                this.chartConfiguration = this.weatherData;
            })
            .subscribe(data => { this.weatherData = data; },
                error => this.errorMessage = <any>error,
            );
        this.onResetControls();

    }

    onSearchLocationWithEvent(event: Event) {
        // console.log("Complete event data value: "+ event);
        console.log('Control value: ' + (<HTMLInputElement>event.target).value);
        this.cityName = (<HTMLInputElement>event.target).value;
        this.disabledButton = false;
    }

    onResetControls() {
        this.cityName = '';
        this.disabledButton = true;
        this.weatherData = '';
    }

}
