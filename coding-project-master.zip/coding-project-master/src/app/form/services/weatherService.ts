import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { environment } from '../../../environments/environment';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import * as _ from 'lodash';
import { formatDate } from '@angular/common';

// const APPID = '45f4dd45e0f724512ba044c5a2caf4bc';

@Injectable()
export class WeatherService {
    weatherList;
    datesList;
    tempList;
    modifiedData;
    windList;
    cityName;
    countryName;
    // private baseUrl='http://api.openweathermap.org/data/2.5/';

    // constructor(@Inject(APP_CONFIG) private config: IAppConfig, private http: Http) { }

    constructor(private http: HttpClient) {
        console.log('Production=' + environment.production);

    }

    getWeatherForecast(cityName): Observable<any[]> {
        // return this.http.get(environment.baseUrl + 'forecast?q=' + cityName + '&appid=' + environment.appId + '&cnt=' + environment.days + '&units=' + environment.units)
        return this.http.get(environment.baseUrl, {
            params: {
                q: cityName,
                appId: environment.appId,
                cnt: environment.days,
                units: environment.units
            }
            // observe: 'response'
        })
            .map(response => this.extractData(response))
            .catch(this.handleError);
    }

    private extractData(res: any) {
        this.modifiedData = [];
        this.cityName = res.city.name;
        this.countryName = res.city.country;
        this.modifiedData = _(res.list)
            .map(e => {
                return {
                    // formatDate(e.dt, 'd MMM', 'en-US')
                    formattedDate: e.dt_txt,
                    temperature: e.main.temp.toFixed(),
                    forecast: e.weather[0].main,
                    forecastDesc: e.weather[0].description,
                    windSpeed: `${e.wind.speed} ${'m/s'}`,
                    humidity: e.main.humidity,
                };
            })
            .value();
        return this.modifiedData || {};
    }

    private handleError(error: any) {
        // In a real world app, we might use a remote logging infrastructure
        let errMsg: string;
        // if (error instanceof Response) {
        //   const body = error.json() || '';
        //   const err = body.error || JSON.stringify(body);
        //   errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
        // } else {
        errMsg = error.message ? error.message : error.toString();
        // }
        console.error(errMsg);
        return Observable.throw(errMsg);
    }
    public getDatesList() {
        return this.datesList = _.chain(this.modifiedData).map(list => formatDate(list.formattedDate, 'dd a hh MMM E', 'en-US')).value();
    }

    public getTempList() {
        return this.tempList = _.chain(this.modifiedData).map(list => list.temperature).value();
    }

    public getWindList() {
        return this.windList = _.chain(this.modifiedData).map(list => list.windSpeed).value();
    }

}
